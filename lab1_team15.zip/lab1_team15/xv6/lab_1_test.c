// #include "types.h"
// #include "x86.h"
// #include "defs.h"
// #include "date.h"
// #include "param.h"
// #include "memlayout.h"
// #include "mmu.h"
// #include "proc.h" // chose these headers because it's the same as sysproc and sysproc is able to call all the sys call functions 
// //                   //with no problem 

// #include "types.h"
// #include "defs.h"
// #include "param.h"
// #include "memlayout.h"
// #include "mmu.h"
// #include "x86.h"
// #include "proc.h"
// #include "spinlock.h"
// #include 

// //USE THESE FOR LATEST BACKUP
// #include "types.h"
// #include "stat.h"
// #include "user.h"

#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"

//for if needed myproc function

// #include "param.h"
// #include "memlayout.h"
// #include "mmu.h"
// #include "x86.h"
// #include "proc.h"
// #include "spinlock.h"

//#include "proc.c" //included for myproc functions which grabs the process that's running 
                    //actually get rid of proc.c because of redefinition of functions since it's not just declrations but definitions
                    //as well
//added for printf statements 
//#include <stdio.h> // don't use library 

//using the same headers as sysproc
//since in that file can call proc fnctions




// #include "types.h"
// #include "x86.h"
// #include "defs.h"
// #include "date.h"
// #include "param.h"
// #include "memlayout.h"
// #include "mmu.h"
// #include "proc.h"
// #include "stat.h"
//run exit debug before parent runs wait


void
printf_1(int fd, const char *s, ...)
{
  write(fd, s, strlen(s));
}
// // //for myproc function
// // void
// // pinit(void)
// // {
// //   initlock(&ptable.lock, "ptable");
// // }

// // Must be called with interrupts disabled
// int
// cpuid() {
//   return mycpu()-cpus;
// }

// // Must be called with interrupts disabled to avoid the caller being
// // rescheduled between reading lapicid and running through the loop.
// struct cpu*
// mycpu(void)
// {
//   int apicid, i;
  
//   if(readeflags()&FL_IF)
//     panic("mycpu called with interrupts enabled\n");
  
//   apicid = lapicid();
//   // APIC IDs are not guaranteed to be contiguous. Maybe we should have
//   // a reverse map, or reserve a register to store &cpus[i].
//   for (i = 0; i < ncpu; ++i) {
//     if (cpus[i].apicid == apicid)
//       return &cpus[i];
//   }
//   panic("unknown apicid\n");
// }

// // Disable interrupts so that we are not rescheduled
// // while reading proc from the cpu structure
// struct proc*
// myproc(void) {
//   struct cpu *c;
//   struct proc *p;
//   pushcli();
//   c = mycpu();
//   p = c->proc;
//   popcli();
//   return p;
// }

void testing_exit_w_int(){
  printf_1(1,"testing exit_w_int\n");
  //for ()
  int pid= fork();
  int status_exit_w_int = 1;
  if (pid == 0){
  exit_w_int(status_exit_w_int);    
  }
  debug();

}

void testing_wait_w_int(){
  printf_1(1,"testing wait_w_int\n");
  int *status_wait_w_int = 0;
  int pid = fork();
  
  if (pid > 0){
    wait_w_int(status_wait_w_int);
    //wait();
    printf_1(1,"parent running after wait_w_int");
  }
  else if (pid ==0 ){
    printf_1(1,"Children running");
  }
  
}

void testing_waitpid(){
  printf_1(1,"testing waitpid\n");
  int *status_waitpid =0 ;
  int pid = fork();
  if (pid >0 ){
    
    printf_1(1,"starting waitpid(pid)\n");
    waitpid(pid,status_waitpid,0);
    printf_1(1,"Paren Process Running\n");
  }
  if (pid == 0){
    printf_1(1,"Child Process running");

  }
}

int main (int argc, char* argv[]){
    // struct proc * curproc = myproc();
    // printf("curproc->pid %i" , curproc->pid);
    
    
    //printf_1(1,argv[1]);
    //  if (argv[1] == '1'){
    //   printf_1(1,"testing exit_w_int\n");
      
    // }
    // else if(argv[1] == '2'){
    //   printf_1(1,"testing wait_w_int\n");

    // }
    // else if (argv[1] == '3'){
    //   printf_1(1,"testing waitpid\n");
    // }

    // else{
    //   printf_1(1,"wrong input for which new syscall to test");  
    // }


    //printf_1(1,"%s",atoi(argv[2]));
    
    //moved to functions instead of it being a variable in main
     int pid = 0;

     int x = 0; // for for loops
      
    //making sure the correct number of arg variables was passed
    if (argc > 3 ){
      printf_1(1,"Too many argument variables passed");
    }
    if (argc < 2){
      printf_1(1,"Not enough argument variables passed");
    }
    //testing exit_w_int
    if (strcmp(argv[1],"1") == 0){
      printf_1(1,"testing exit_w_int 10 times\n");
      for(x = 0; x < 10; x++){
      pid= fork();
      int status_exit_w_int = 1;
      if (pid == 0){
      exit_w_int(status_exit_w_int);    
      }
      else{
        wait();
        }
      }
      printf_1(1,"Exit_w_int tests ran succesfully \n");
      //debug();
      //testing_exit_w_int();
    }

    //testing wait_w_int
    else if(strcmp(argv[1],"2") == 0){
      printf_1(1,"testing wait_w_int 10 times\n");
      for( x = 0; x < 10; x++){
      int status_wait_w_int_memory;
      int *status_wait_w_int = &status_wait_w_int_memory;
      
      pid = fork();
      
      if (pid > 0){
        printf_1(1,"Starting  wait_w_int\n");
        if (wait_w_int(status_wait_w_int) == -1){
          printf_1(1,"wait_w_int_error return -1");
          break;
        }

        //wait();
        printf_1(1,"parent proc running after wait_w_int\n\n");
      }
      else if (pid ==0 ){
        printf_1(1,"Child process running\n");
        exit();
        }
      }
      printf_1(1,"wait_w_int tests ran succesfully \n");
      //testing_wait_w_int();
      
    }//end of testing wait_w_int


    //testing waitpid
    else if (strcmp(argv[1],"3") == 0){
      printf_1(1,"testing waitpid 10 times\n");
     for(x = 0; x < 10; x++){
     int status_waitpid_memory;
     int *status_waitpid = &status_waitpid_memory;
     pid = fork();

      if (pid >0 ){
        printf_1(1,"starting waitpid\n");
        //waitpid(pid,status_waitpid,0);
        if (waitpid(pid,status_waitpid,0) == -1){
          printf_1(1,"wait_w_int_error return -1");
          break;
        }
        printf_1(1,"Paren Process Running\n\n");
      }
      if (pid == 0){
        printf_1(1,"Child Process running\n");
        exit();
      }
     }// end of for loop tests

      printf_1(1,"wait_pid tests ran succesfully \n");
      //testing_waitpid();
    }

        //testing waitpid
    else if (strcmp(argv[1],"4") == 0){
      printf_1(1,"testing debug\n");
    //  int status_waitpid_memory;
    //  int *status_waitpid = &status_waitpid_memory;
     pid = fork();

      if (pid >0 ){
        wait();
        printf_1(1,"Paren Process Running\n");
        
        debug();
        
      }
      if (pid == 0){
        printf_1(1,"Child Process Running \n");
        debug();
      }
    

      //testing_waitpid();
    }
    
    else{
      printf_1(1,"wrong input for which new syscall to test \n" );  
    }

    
    //printf_1(1,"HELLO!\n");
    
    //wait();
    //exit();

    exit();


}